#!/usr/bin/env bash

git remote prune origin
